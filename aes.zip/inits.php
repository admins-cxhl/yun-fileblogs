<?php
/**
 * 初始化开始
 */

// 路径
defined('YUN_ROOT_FILES') || define('YUN_ROOT_FILES', dirname(__FILE__) . DIRECTORY_SEPARATOR);

// 时区设置
date_default_timezone_set('Asia/Shanghai');