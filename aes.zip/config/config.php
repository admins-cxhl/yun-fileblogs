<?php
/**
 * 配置-可以自定义修改
 */

return array(
	
	/**
    * http请求协议
    */
	'http' => 'http://',
	
	/**
    * api链接
    */
	'url' => 'wdswebapi.ecsxs.com/',
	
	/**
    * api地址
    */
	'phps' => 'wds.php',
	
	
	
	/**
    * 你的id
    */
	'userid' => '',
	
	/**
    * 你的用户名
    */
	'username' => '',
	
	
	
	
	/**
    * 服务器配置名，如果有多个服务器做负载均衡可以修改配置名字-实现不同服务器访问统计
    */
	'version-type' => 'vps1',
	
	/**
    * 当前api版本
    */
	'version' => '1.0.0',
	

);
